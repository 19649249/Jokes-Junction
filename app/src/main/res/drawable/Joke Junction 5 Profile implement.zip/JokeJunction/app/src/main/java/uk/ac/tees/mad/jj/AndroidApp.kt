package uk.ac.tees.mad.jj

import android.app.Application
import dagger.hilt.android.HiltAndroidApp


@HiltAndroidApp
class AndroidApp: Application()